g++ -O3 future_net.cpp liblpsolve55.a -l dl -o ../future_net
