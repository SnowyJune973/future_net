#define _OK 0
#define _A_WRONG_DEMANDED_POINT_NUMBER 2
#define _UNSOLVABLE_START_END_NOT_CONNECTED 3
#define _TO_BE_KILLED 55555555
const int maxn = 700;
const int inf = 0x33333333;

